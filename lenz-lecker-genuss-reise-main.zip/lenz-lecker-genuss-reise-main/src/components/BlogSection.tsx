
const BlogSection = () => {
  return null;
};

export default BlogSection;
